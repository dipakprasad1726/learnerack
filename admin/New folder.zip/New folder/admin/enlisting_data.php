<?php
include_once '../headers/admin_header.php';
?>
    </head>
    <body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#myPage">LearneracK.c<span class="glyphicon glyphicon-globe"></span>m</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="../Utilities/logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->
        </nav>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">Data Enlistment <a class="navbar-right" style="font-size: small  " href="dashboard.php"> Cancel</a></h2>
                    
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <form role="form" action="#" method="post">
            <div class="panel-body">
                <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4>Basic Information</h4>
                        </div>
                        <div class="panel-body">
                <div class="row">
                    
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                <label>Authorized Person</label>
                                <input placeholder="Authorized person name" class="form-control" name="authorizedPerson" type="text">
    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>School Name</label>
      <input class="form-control" name="schoolName" value="<?php echo $schoolName?>" type="text">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Chain Name</label>
      <input class="form-control" placeholder="Chain Name" name="chainName" type="text" placeholder="chain name">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Affiliation</label>
      <input class="form-control" name="affiliation" type="text" placeholder="affiliation">
                                        </div>
                                </div>
                        </div>
                <div class="row">
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                <label>Primary Contact</label>
      <input class="form-control" name="primaryContact" type="text" placeholder="primary contact">
    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Secondary Contact</label>
      <input class="form-control" name="secondaryContact" type="text" placeholder="secondry contact">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Email Id</label>
      <input class="form-control" name="emailId" type="text" placeholder="email">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Website url</label>
      <input class="form-control" name="website" type="text" placeholder="url">
                                        </div>
                                </div>
                        </div>
                        <div class="row">
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                <label>Tag line</label>
      <input class="form-control" name="tagLine" type="text"  placeholder="tag line">
    </div>
                                </div>                                
                        </div>
                        </div>
                </div>
                <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4>School Addreess</h4>
                        </div>
                        <div class="panel-body">
                <div class="row">
                    
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                <label>Address Line 1</label>
      <input class="form-control" name="addressLine1" type="text"  placeholder="address line 1">
    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Address Line 2</label>
      <input class="form-control" name="addressLine2" type="text" placeholder="address line 2">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>City</label>
      <input class="form-control" name="city" type="text" placeholder="city">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>State</label>
      <input class="form-control" name="state" type="text" placeholder="state">
                                        </div>
                                </div>
                        </div>
                <div class="row">
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                <label>Pin Code</label>
      <input class="form-control" name="pinCode" type="text" placeholder="pincode">
    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Country</label>
      <input class="form-control" name="country" type="text" placeholder="country">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Nearest Land Mark</label>
      <input class="form-control" name="landMark" type="text" placeholder="nearest landmark">
                                        </div>
                                </div>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4>Detailed Information</h4>
                        </div>
                        <div class="panel-body">
                <div class="row">
                    
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                <label>Establishment Year</label>
      <input class="form-control" name="establishmentYear" type="number">
    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Type Of School</label>
      <input class="form-control" name="typeOfSchool" type="text" placeholder="type to school">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Campus Area</label>
      <input class="form-control" name="campusArea" type="text" placeholder="area in sq. m ">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Class Range From</label>
      <input class="form-control" name="classRangeFrom" type="text" placeholder="class range from">
                                        </div>
                                </div>
                        </div>
                <div class="row">
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                <label>Class Range To</label>
      <input class="form-control" name="classRangeTo" type="text" placeholder="class range to">
    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Number of Teachers in primary</label>
      <input class="form-control" name="numberOfTeachersPrimary" type="number" value="">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Number of Teachers in secondary</label>
      <input class="form-control" name="numberOfTeachersSecondary" type="number" value="">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Number of Teachers in higher secondary</label>
      <input class="form-control" name="numberOfTeachersHigherSecondary" type="number" value="">
                                        </div>
                                </div>
                </div>
                <div class="row">
                                <div class="col-lg-6 col-md-6">                                    
                                        <div class="form-group">
                                <label>About School</label>
                                <textarea class="form-control" name="aboutSchool" rows="5" ></textarea>
    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>School Hours From</label>
      <input class="form-control" name="schoolHoursFrom" type="text" placeholder="enter hh:mm am/pm">
                                        </div>
                                        <div class="form-group">
                                            <label>School Hours To</label>
      <input class="form-control" name="schoolHoursTo" type="text" placeholder="enter hh:mm am/pm">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Council Name</label>
      <input class="form-control" name="councilName" type="text" placeholder="board name">
                                        </div>
                                </div>
                </div>
                        <div class="row">
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                <label>School Performance 10th</label>
      <input class="form-control" name="schoolPerformanceTenth" type="text" placeholder="percentage followed by year">
      <i>Eg. '84 2015', '91 2016'</i>
    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>School Performance 12th</label>
      <input class="form-control" name="schoolPerformanceTwelveth" type="text"  placeholder="percentage followed by year">
      <i>Eg. '84 2015', '91 2016'</i>
                                        </div>
                                </div>                                
                </div>
                            
                    </div>
                </div>
                                <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4>School Facilities</h4>
                        </div>
                        <div class="panel-body">
                <div class="row">
                    
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                <label>Transport</label>
        &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="transport">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="transport" checked>No
    </label>
    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Physics Lab</label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="physicslab">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="physicslab" checked>No
    </label>
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Chemistry Lab</label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="chemistrylab">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="chemistrylab" checked>No
    </label>
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Biology Lab</label>
&nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="biologylab">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="biologylab" checked>No
    </label>
                                        </div>
                                </div>
                        </div>
                <div class="row">
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                <label>Computer Lab</label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="computerlab">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="computerlab" checked>No
    </label>
    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Other Labs</label>
      <input class="form-control" name="otherLabs" type="text">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Cafeteria</label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="cafeteria">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="cafeteria" checked>No
    </label>
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Gym</label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="gym">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="gym" checked>No
    </label>
                                        </div>
                                </div>
                        </div>
                            <div class="row">
                    
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                <label>Auditorium</label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="auditorium">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="auditorium" checked>No
    </label>
    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Swimming Pool</label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="swimmingPool">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="swimmingPool" checked>No
    </label>
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Medical Center</label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="medicalCenter">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="medicalCenter" checked>No
    </label>
                                        </div>
                                </div>
                                
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4>Co-curricular Activities</h4>
                        </div>
                        <div class="panel-body">
                <div class="row">
                    
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                <label>Singing</label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="singing">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="singing" checked>No
    </label>
    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Dance</label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="dance">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="dance" checked>No
    </label>
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Communication</label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="communication">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="communication" checked>No
    </label>
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Music</label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="music">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="music" checked>No
    </label>
                                        </div>
                                </div>
                        </div>
                <div class="row">
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                <label>Sports</label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="sports">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="sports" checked>No
    </label>
    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Defense Training(Karatey/Tiekwondu) </label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="defenceTraining">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="defenceTraining" checked>No
    </label>
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Yoga</label>
      &nbsp;&nbsp;&nbsp;
      <label class="radio-inline">
      <input type="radio" name="yoga">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="yoga" checked>No
    </label>
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Others</label>
      <input class="form-control" name="othersCCAC" type="text" placeholder="others">
                                        </div>
                                </div>
                </div>
                <div class="row">
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                <label>Scholarship Given</label>
      &nbsp;&nbsp;&nbsp; 
      <label class="radio-inline">
      <input type="radio" name="scholarship">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="scholarship" checked>No
    </label>
    </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Subject Combination for Primary</label>
      <input class="form-control" name="subjectPrimary" type="text" placeholder="enter subject comma saparated">
      <i>Eg. 'English,Hindi,Geography,History'</i>
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Subject Combination for Secondary</label>
      <input class="form-control" name="subjectSecondary" type="text" placeholder="enter subject comma saparated">
      <i>Eg. 'English,Hindi,Geography,History'</i>
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Subject Combination for Higher Secondary</label>
      <input class="form-control" name="subjectHS" type="text" placeholder="enter subject comma saparated">
      <i>Eg. 'English,Hindi,Geography,History'</i>
                                        </div>
                                </div>
                </div>
                            
                    </div>
                </div>
                                <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4>Admission Procedure</h4>
                        </div>
                        <div class="panel-body">
                <div class="row">                    
                                <div class="col-md-6 col-md-offset-3">                                  
                                        <div class="form-group">
                                <div class="table-responsive">
                                <table class="table table-striped table-bordered">
          <tr><th>About</th><th>Primary</th><th>Secondary</th><th>HS</th></tr>
          <tr>
              <td>Minimum Age</td><td><input name="minAgePri" type="text" size="2" maxlength="2"></td>
              <td><input name="minAgeSec" type="text" size="2" maxlength="2"></td>
              <td><input name="minAgeHS" type="text" size="2" maxlength="2" ></td>
          </tr>
          <tr>
              <td>Minimum Marks</td><td><input name="minMarksPri" type="text" size="2" maxlength="2"></td>
              <td><input name="minMarksSec" type="text" size="2" maxlength="2"></td>
              <td><input name="minMarksHS" type="text" size="2" maxlength="2"></td>
          </tr>
          <tr>
              <td>Interview</td>
              <td><select name="minAgePri"><option value="NO">NO</option><option value="YES">YES</option></select></td>
              <td><select name="minAgeSec"><option value="NO">NO</option><option value="YES">YES</option></select></td>
              <td><select name="minAgeHS"><option value="NO">NO</option><option value="YES">YES</option></select></td>
          </tr>
          <tr>
              <td>Entrance Exam</td>
              <td><select name="examPri"><option value="NO">NO</option><option value="YES">YES</option></select></td>
              <td><select name="examSec"><option value="NO">NO</option><option value="YES">YES</option></select></td>
              <td><select name="examHS"><option value="NO">NO</option><option value="YES">YES</option></select></td>
          </tr>
          <tr>
              <td>Pass Score</td><td><input name="passScorePri" type="text" size="2" maxlength="2"></td>
              <td><input name="passScoreSec" type="text" size="2" maxlength="2"></td>
              <td><input name="passScoreHS" type="text" size="2" maxlength="2"></td>
          </tr>
          
      </table>
    </div>
                    </div>
                                        </div>
                                                                
                </div>
                            
                    </div>
                </div>
                <div class="row">                    
                <div class="col-md-6 col-md-offset-3">
                    <center>
                <input type="submit" value="Save" class="btn btn-info disabled">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="submit" value="Submit" class="btn btn-info">
                </center> 
                </div>
                </div>
                    </div>
                </form>
        </div>
    </div>
        <?php
        // put your code here
        ?>
    </body>
</html>
