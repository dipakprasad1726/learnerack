<?php
include_once '../headers/admin_header.php';
?>
    <script type="text/javascript">
window.onload = function () {
	var chart = new CanvasJS.Chart("chartContainer",
	{
	        data: [              
		{
			type: "column",
                        dataPoints: [
				{ label: "Total Survey",  y: 40  },
				{ label: "Enlistment", y: 15  },
				{ label: "Schools", y: 25  },
				{ label: "Collages",  y: 30  }
			]
		}
		]
	});
	chart.render();	
}
</script>
<script type="text/javascript" src="../js/canvasjs.min.js"></script>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php
    include_once '../headers/admin_menu.php';
    ?>
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">Survay Data Upload</h2>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Survay Data Statistics                            
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div id="chartContainer" style="height: 200px; width: 100%;"></div>
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>
            </div>
            <form role="form" action="#" method="post">
            <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-3 col-md-6">                                    
                                        <div class="form-group">
                                            <label>Area</label>
                                            <select class="form-control" id="area" name="area">
                                                <option value="bangalore">Bangalore</option>
                                            </select>
                                        </div>
                                    <div class="form-group">
                                            <label>Type</label>
                                            <select class="form-control" id="type" name="type">
                                                <option value="SC">School</option>
                                                <option value="CO">Collage</option>
                                            </select>
                                        </div>
                                    </div>
                            
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Institution Name</label>
                                            <input class="form-control" name="institutionName" placeholder="School/Collage name">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Latitude</label>
                                            <input class="form-control" name="latitude" placeholder="latitude">
                                        </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
                                        <div class="form-group">
                                            <label>Longitude</label>
                                            <input class="form-control" name="longitude" placeholder="longitude">
                                        </div>
                                </div>
                            </div>    
                <center>                        
                <button type="submit" class="btn btn-primary">Upload</button>
                        </center>                
                    </div>
            </form>
            </div>            
        </div>        
        <!-- /#page-wrapper -->

    <!-- /#wrapper -->
    
</body>

</html>
