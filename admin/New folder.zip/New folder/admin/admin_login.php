<!DOCTYPE html>
<html lang="en">
<?php
session_start();
//if(isset($_SESSION['passcode'])){
//    die(header("Location:scoutspanel.php"));
//}
$message="";       
       if(isset($_POST["signin"])){
           //include 'Utilities/connection.php';
require_once('../Utilities/connection.php');
$email=$_POST["email"];
$pwd=$_POST["password"];
$stmt=  mysqli_prepare($con, "select Employee_Id,First_Name,Role from Employee where Email_Official='$email' and Password='$pwd'");
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt,$uid,$uname,$role);

if(mysqli_stmt_fetch($stmt)){
    $_SESSION['passcode']='1234';
    $_SESSION['email']=$email;
    $_SESSION['role']=$role;
   // $_SESSION['empId']=$uid;
    header("Location: dashboard.php");
}else{
    $message="Invalid email or password...";
}
}
        ?>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>LearneracK Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
 <style>
      .navbar {
      margin-bottom: 0;
      background-color: #269abc;
      z-index: 9999;
      border: 0;
      font-size: 12px !important;
      line-height: 1.42857143 !important;
      letter-spacing: 4px;
      border-radius: 0;
      font-family: Montserrat, sans-serif;
  }
  .navbar li a, .navbar .navbar-brand {
      color: #fff !important;
  }
  .navbar-nav li a:hover, .navbar-nav li.active a {
      color: #269abc !important;
      background-color: #fff !important;
  }
  .navbar-default .navbar-toggle {
      border-color: transparent;
      color: #fff !important;
  }
    .anc{
      color: #efefef;
      font-size: xx-large;
      margin-top: 10%
      
  }
</style>
</head>

<body>
<nav class="navbar navbar-default navbar-fixed-top"  style="background-color: #269abc">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
      </button>
        <a class="navbar-brand" href="#myPage">LearneracK.c<span class="glyphicon glyphicon-globe"></span>m</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="home.php"><p class="fa fa-home"></p>HOME</a></li>
        <li><a href="#contact">CONTACT US</a></li>
      </ul>
    </div>
  </div>
</nav>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Please Sign In</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" method="post">
                            <label for="Error"><?php echo "<font color=red><h4>".$message."</h4></font>";?></label>
                            <fieldset>                                
                                <div class="form-group">
                                    <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" value="">
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input name="remember" type="checkbox" value="Remember Me">Remember Me
                                    </label>
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                                <input type="submit" name="signin" value="LOGIN" class="btn btn-lg btn-primary btn-block">
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
