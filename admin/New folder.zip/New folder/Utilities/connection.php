<?php
$host="localhost";
$user="root";
$password="";
$database="learnerack";
$con=  mysqli_connect($host, $user, $password, $database);
//check connection
if(mysqli_connect_errno($con)){
    echo "<font color=red><h1>Fail to connect to MySQL : ".mysqli_connect_error()."</h1></font>";
}

?>
