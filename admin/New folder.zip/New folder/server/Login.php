<?php

include 'http://localhost/Learnerack/Utilities/connection.php';
//require 'Utilities/connection.php';
$email=$_POST["email"];
$pwd=$_POST["pwd"];

$stmt=  mysqli_prepare($con, "select * from employee where password=".$pwd);
mysqli_stmt_execute($stmt);
//mysqli_stmt_bind_result($stmt,$uid,$uname);
if(mysqli_stmt_fetch($stmt)){
    //printf("%d -- %s<br>",$uid,$uname);
    header("Location: http://localhost/Learnerack/loginsuccess.php");
}else{
    printf("Inavlid user");
    die("dead");
    header("Location: http://localhost/Learnerack/loginfailure.php");
}
session_start();


?>
